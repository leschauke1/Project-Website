import {
  Code2,
  Database,
  Layout,
  Server,
  GitBranch,
  Cloud,
  Cpu,
  Terminal,
  Users,
  MessageSquare,
  Presentation,
  Clock,
  type LucideIcon,
} from 'lucide-react';

export const profile = {
  name: 'Lesley Nkateko Chauke',
  role: 'Software Developer',
  tagline: 'I build accessible, performant web applications that people love to use.',
  email: 'lesley.chauke@example.com',
  github: 'https://github.com/lesleychauke',
  linkedin: 'https://www.linkedin.com/in/lesleychauke',
  location: 'Johannesburg, Gauteng',
  summary:
    'Software developer passionate about building accessible, performant web applications. I care deeply about clean architecture, thoughtful UX, and writing code my teammates enjoy working in. Currently focused on React, TypeScript, and serverless architectures.',
};

export const stats = [
  { value: '1', label: 'Years Experience' },
  { value: '3+', label: 'Projects Shipped' },
  { value: '1', label: 'Certification' },
  { value: '1', label: 'Diploma' },
];

export type Skill = {
  name: string;
  level: number;
  icon: LucideIcon;
};

export const technicalSkills: Skill[] = [
  { name: 'TypeScript / JavaScript', level: 95, icon: Code2 },
  { name: 'React / Next.js', level: 92, icon: Layout },
  { name: 'Node.js / Express', level: 88, icon: Server },
  { name: 'PostgreSQL / Supabase', level: 85, icon: Database },
  { name: 'AWS / Cloud Infrastructure', level: 80, icon: Cloud },
  { name: 'Docker / CI/CD', level: 78, icon: GitBranch },
  { name: 'Python / Data Scripting', level: 75, icon: Terminal },
  { name: 'System Design', level: 82, icon: Cpu },
];

export const softSkills = [
  { name: 'Team Collaboration', icon: Users, description: 'Cross-functional work with designers, PMs, and engineers.' },
  { name: 'Clear Communication', icon: MessageSquare, description: 'Translating technical concepts for any audience.' },
  { name: 'Public Speaking', icon: Presentation, description: 'Conference talks and internal tech sessions.' },
  { name: 'Time Management', icon: Clock, description: 'Shipping reliably with structured prioritization.' },
];

export type Project = {
  title: string;
  description: string;
  longDescription: string;
  technologies: string[];
  highlights: string[];
  link: string;
  repo: string;
  image: string;
  featured: boolean;
};

export const projects: Project[] = [
  {
    title: 'TaskFlow — Project Management App',
    description: 'A real-time collaborative task manager with drag-and-drop boards and team workspaces.',
    longDescription:
      'A full-featured project management platform supporting real-time collaboration, Kanban boards with drag-and-drop, role-based access control, and automated workflow triggers. Built to handle 500+ concurrent users.',
    technologies: ['React', 'TypeScript', 'Supabase', 'Tailwind CSS', 'Vercel'],
    highlights: [
      'Real-time sync across 500+ concurrent users',
      'Role-based access with row-level security',
      'Drag-and-drop board powered by dnd-kit',
    ],
    link: 'https://taskflow.example.com',
    repo: 'https://github.com/alexcarter/taskflow',
    image: 'https://images.pexels.com/photos/3781338/pexels-photo-3781338.jpeg?auto=compress&cs=tinysrgb&w=800',
    featured: true,
  },
  {
    title: 'DataLens — Analytics Dashboard',
    description: 'An interactive analytics dashboard with customizable widgets and exportable reports.',
    longDescription:
      'A self-serve analytics platform that lets non-technical teams build dashboards from raw data. Includes a visual query builder, 12 chart types, scheduled email reports, and CSV/PDF export.',
    technologies: ['Next.js', 'TypeScript', 'PostgreSQL', 'Recharts', 'AWS Lambda'],
    highlights: [
      'Visual query builder for non-technical users',
      '12 chart types with live preview',
      'Scheduled email reports with PDF export',
    ],
    link: 'https://datalens.example.com',
    repo: 'https://github.com/alexcarter/datalens',
    image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800',
    featured: true,
  },
  {
    title: 'DevMatch — Developer Networking',
    description: 'A matching platform connecting developers for pair programming and open-source collaboration.',
    longDescription:
      'A social platform that pairs developers by skill level, timezone, and project interests. Features real-time chat, calendar integration, and a reputation system based on merged contributions.',
    technologies: ['React', 'Node.js', 'Socket.io', 'MongoDB', 'Docker'],
    highlights: [
      'Skill-based matching algorithm',
      'Real-time chat with Socket.io',
      'GitHub-integrated reputation system',
    ],
    link: 'https://devmatch.example.com',
    repo: 'https://github.com/alexcarter/devmatch',
    image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800',
    featured: true,
  },
];

export type Education = {
  degree: string;
  institution: string;
  period: string;
  description: string;
  gpa: string;
};

export const education: Education[] = [
  {
    degree: 'Diploma in Software Development',
    institution: 'Rosebank College',
    period: 'Johannesburg, Gauteng',
    description:
      'Comprehensive program covering software development fundamentals, programming principles, database management, and modern web technologies.',
    gpa: 'Diploma',
  },
];

export type Certification = {
  title: string;
  issuer: string;
  date: string;
  credentialId: string;
};

export const certifications: Certification[] = [
  {
    title: 'Google AI Essentials',
    issuer: 'Coursera',
    date: '2024',
    credentialId: 'GOOGL-AI-2024',
  },
];

export type Experience = {
  role: string;
  company: string;
  period: string;
  location: string;
  description: string;
  achievements: string[];
};

export const experience: Experience[] = [
  {
    role: 'Sales Representative',
    company: 'Nashua',
    period: '3 Month Contract',
    location: 'Johannesburg, Gauteng',
    description:
      'Recruiting clients to buy our products to reach target.',
    achievements: [
      'Engaged with potential clients to promote and sell company products',
      'Worked towards meeting and exceeding sales targets',
    ],
  },
];

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Experience', href: '#experience' },
  { label: 'Education', href: '#education' },
  { label: 'Contact', href: '#contact' },
];
