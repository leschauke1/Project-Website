import { useState } from 'react';
import { ExternalLink, Github, CheckCircle2 } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { projects } from '@/data/portfolio';
import type { Project } from '@/data/portfolio';

function ProjectCard({ project, index }: { project: Project; index: number }) {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();
  const isReversed = index % 2 === 1;

  return (
    <div
      ref={ref}
      className={`reveal ${isVisible ? 'is-visible' : ''} grid lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
        isReversed ? 'lg:[direction:rtl]' : ''
      }`}
    >
      <div className={`relative group ${isReversed ? 'lg:[direction:ltr]' : ''}`}>
        <div className="absolute -inset-3 bg-gradient-to-tr from-brand-500/15 to-accent-500/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <div className="relative aspect-[4/3] rounded-2xl overflow-hidden border border-ink-200 shadow-lg">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950/50 to-transparent" />
          <div className="absolute bottom-4 left-4 flex gap-2">
            <a
              href={project.link}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-lg bg-white/90 backdrop-blur-sm text-ink-800 hover:bg-white transition-colors"
              aria-label="Live demo"
            >
              <ExternalLink size={18} />
            </a>
            <a
              href={project.repo}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-lg bg-white/90 backdrop-blur-sm text-ink-800 hover:bg-white transition-colors"
              aria-label="Source code"
            >
              <Github size={18} />
            </a>
          </div>
        </div>
      </div>

      <div className={isReversed ? 'lg:[direction:ltr]' : ''}>
        <span className="inline-block px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold mb-3">
          Featured Project
        </span>
        <h3 className="font-display font-bold text-2xl lg:text-3xl text-ink-900 mb-3">
          {project.title}
        </h3>
        <p className="text-ink-600 leading-relaxed mb-4">{project.longDescription}</p>
        <ul className="space-y-2 mb-5">
          {project.highlights.map((h) => (
            <li key={h} className="flex items-start gap-2 text-sm text-ink-600">
              <CheckCircle2 className="text-brand-500 mt-0.5 shrink-0" size={18} />
              {h}
            </li>
          ))}
        </ul>
        <div className="flex flex-wrap gap-2">
          {project.technologies.map((tech) => (
            <span
              key={tech}
              className="px-3 py-1 rounded-md bg-ink-100 text-ink-600 text-xs font-medium"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export function Projects() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'Web App', 'Full-Stack', 'Open Source'];

  return (
    <section id="projects" className="py-20 lg:py-28 bg-white">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <div className="text-center mb-14">
          <p className="text-brand-600 font-semibold text-sm tracking-widest uppercase">Projects</p>
          <h2 className="mt-2 font-display font-bold text-3xl lg:text-4xl text-ink-900">
            Things I've built
          </h2>
          <div className="mt-4 w-16 h-1 bg-brand-500 rounded-full mx-auto" />
        </div>

        {/* Filter pills (visual only) */}
        <div className="flex justify-center gap-2 mb-12 flex-wrap">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeFilter === f
                  ? 'bg-ink-900 text-white'
                  : 'bg-ink-100 text-ink-600 hover:bg-ink-200'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="space-y-20">
          {projects.map((project, i) => (
            <ProjectCard key={project.title} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
