import { useScrollReveal } from '@/hooks/useScrollReveal';
import { profile, softSkills } from '@/data/portfolio';
import { Download } from 'lucide-react';

export function About() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="about" className="py-20 lg:py-28 bg-white">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <div className="text-center mb-14">
          <p className="text-brand-600 font-semibold text-sm tracking-widest uppercase">About Me</p>
          <h2 className="mt-2 font-display font-bold text-3xl lg:text-4xl text-ink-900">
            Get to know me
          </h2>
          <div className="mt-4 w-16 h-1 bg-brand-500 rounded-full mx-auto" />
        </div>

        <div className="grid lg:grid-cols-5 gap-10 lg:gap-16 items-start">
          {/* Summary */}
          <div className="lg:col-span-3 space-y-6">
            <h3 className="font-display font-semibold text-2xl text-ink-800">
              Turning ideas into reliable, delightful software
            </h3>
            <p className="text-lg text-ink-600 leading-relaxed">
              {profile.summary}
            </p>
            <p className="text-ink-600 leading-relaxed">
              I started writing code because I wanted to build things that people use every day.
              That same drive shapes how I work now: I sweat the details that make software feel
              effortless — the loading state nobody notices, the empty state that guides instead of
              confuses, the API call that fails gracefully. I believe great products come from
              equal parts engineering rigor and genuine empathy for the person on the other side
              of the screen.
            </p>
            <p className="text-ink-600 leading-relaxed">
              When I'm not coding, you'll find me exploring new technologies, learning about
              AI, and looking for ways to grow as a developer.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <a
                href="#contact"
                className="inline-flex items-center px-6 py-3 rounded-xl bg-ink-900 text-white font-semibold hover:bg-ink-800 transition-colors"
              >
                Let's work together
              </a>
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-ink-200 text-ink-700 font-semibold hover:bg-ink-50 transition-colors"
              >
                <Download size={18} /> Download CV
              </button>
            </div>
          </div>

          {/* Soft skills */}
          <div className="lg:col-span-2 grid sm:grid-cols-2 gap-4">
            {softSkills.map((skill) => (
              <div
                key={skill.name}
                className="p-5 rounded-2xl border border-ink-100 bg-ink-50/50 hover:bg-white hover:shadow-lg hover:border-brand-200 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-xl bg-brand-100 flex items-center justify-center mb-3">
                  <skill.icon className="text-brand-600" size={22} />
                </div>
                <h4 className="font-semibold text-ink-900">{skill.name}</h4>
                <p className="mt-1 text-sm text-ink-500 leading-relaxed">{skill.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
