import { useScrollReveal } from '@/hooks/useScrollReveal';
import { technicalSkills } from '@/data/portfolio';

export function Skills() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="skills" className="py-20 lg:py-28 bg-ink-50">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <div className="text-center mb-14">
          <p className="text-brand-600 font-semibold text-sm tracking-widest uppercase">Skills</p>
          <h2 className="mt-2 font-display font-bold text-3xl lg:text-4xl text-ink-900">
            Technical expertise
          </h2>
          <div className="mt-4 w-16 h-1 bg-brand-500 rounded-full mx-auto" />
        </div>

        <div className="grid md:grid-cols-2 gap-x-12 gap-y-6 max-w-5xl mx-auto">
          {technicalSkills.map((skill, i) => (
            <div key={skill.name} className="group">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white border border-ink-200 flex items-center justify-center group-hover:border-brand-300 group-hover:bg-brand-50 transition-colors">
                    <skill.icon className="text-ink-600 group-hover:text-brand-600 transition-colors" size={18} />
                  </div>
                  <span className="font-medium text-ink-800">{skill.name}</span>
                </div>
                <span className="text-sm font-semibold text-ink-500">{skill.level}%</span>
              </div>
              <div className="h-2.5 rounded-full bg-ink-200 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-brand-400 to-brand-600 transition-all duration-1000 ease-out"
                  style={{
                    width: isVisible ? `${skill.level}%` : '0%',
                    transitionDelay: `${i * 100}ms`,
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Tech badges */}
        <div className="mt-14 flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
          {[
            'React', 'Next.js', 'TypeScript', 'Node.js', 'Express', 'PostgreSQL',
            'Supabase', 'Tailwind CSS', 'AWS', 'Docker', 'Python', 'Git',
            'Jest', 'GraphQL', 'Redis', 'Vercel',
          ].map((tech) => (
            <span
              key={tech}
              className="px-4 py-2 rounded-lg bg-white border border-ink-200 text-sm font-medium text-ink-600 hover:border-brand-300 hover:text-brand-600 hover:shadow-sm transition-all"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
