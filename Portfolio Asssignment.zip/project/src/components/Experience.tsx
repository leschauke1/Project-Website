import { Briefcase, MapPin, Calendar } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { experience } from '@/data/portfolio';

export function Experience() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="experience" className="py-20 lg:py-28 bg-ink-50">
      <div
        ref={ref}
        className={`max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <div className="text-center mb-14">
          <p className="text-brand-600 font-semibold text-sm tracking-widest uppercase">Experience</p>
          <h2 className="mt-2 font-display font-bold text-3xl lg:text-4xl text-ink-900">
            Where I've worked
          </h2>
          <div className="mt-4 w-16 h-1 bg-brand-500 rounded-full mx-auto" />
        </div>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-5 lg:left-1/2 top-0 bottom-0 w-0.5 bg-ink-200 lg:-translate-x-1/2" />

          {experience.map((exp, i) => (
            <div
              key={exp.role}
              className={`relative mb-12 lg:mb-0 lg:mb-12 flex ${
                i % 2 === 0 ? 'lg:flex-row-reverse' : 'lg:flex-row'
              } items-start gap-6 lg:gap-0`}
            >
              {/* Dot */}
              <div className="absolute left-5 lg:left-1/2 top-2 w-4 h-4 rounded-full bg-brand-500 border-4 border-ink-50 lg:-translate-x-1/2 z-10" />

              {/* Spacer for desktop */}
              <div className="hidden lg:block lg:w-1/2" />

              {/* Card */}
              <div className={`flex-1 lg:w-1/2 pl-14 lg:pl-0 ${i % 2 === 0 ? 'lg:pr-12' : 'lg:pl-12'}`}>
                <div className="p-6 rounded-2xl bg-white border border-ink-100 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-2 text-brand-600 mb-2">
                    <Briefcase size={16} />
                    <span className="text-sm font-semibold">{exp.period}</span>
                  </div>
                  <h3 className="font-display font-bold text-xl text-ink-900">{exp.role}</h3>
                  <p className="text-brand-600 font-medium mt-1">{exp.company}</p>
                  <p className="flex items-center gap-1.5 text-sm text-ink-400 mt-1">
                    <MapPin size={14} /> {exp.location}
                  </p>
                  <p className="mt-4 text-ink-600 leading-relaxed text-sm">{exp.description}</p>
                  <ul className="mt-4 space-y-2">
                    {exp.achievements.map((a) => (
                      <li key={a} className="flex items-start gap-2 text-sm text-ink-600">
                        <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-brand-500 shrink-0" />
                        {a}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
