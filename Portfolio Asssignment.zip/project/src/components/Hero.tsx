import { ArrowDown, Github, Linkedin, Mail, MapPin } from 'lucide-react';
import { profile, stats } from '@/data/portfolio';

export function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-ink-950"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-brand-500/20 rounded-full blur-[120px] animate-float" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-accent-500/10 rounded-full blur-[120px] animate-float" style={{ animationDelay: '2s' }} />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-ink-950" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-16 lg:py-24">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-6 animate-fade-in">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500" />
            </span>
            <span className="text-sm text-ink-300 font-medium">Available for new opportunities</span>
          </div>

          <h1 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-white leading-[1.1] tracking-tight animate-slide-up">
            Hi, I'm <span className="text-gradient">{profile.name}</span>
            <br />
            <span className="text-ink-300 text-3xl sm:text-4xl lg:text-5xl">{profile.role}</span>
          </h1>

          <p className="mt-6 text-lg lg:text-xl text-ink-400 max-w-2xl mx-auto leading-relaxed animate-slide-up" style={{ animationDelay: '0.15s' }}>
            {profile.tagline}
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <a
              href="#projects"
              className="inline-flex items-center px-6 py-3 rounded-xl bg-brand-500 text-white font-semibold hover:bg-brand-600 transition-all duration-200 shadow-lg shadow-brand-500/30 hover:shadow-brand-500/50 hover:-translate-y-0.5"
            >
              View My Work
            </a>
            <a
              href="#contact"
              className="inline-flex items-center px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-semibold hover:bg-white/10 transition-all duration-200 backdrop-blur-sm"
            >
              Contact Me
            </a>
          </div>

          {/* Social links */}
          <div className="mt-8 flex items-center justify-center gap-3 animate-slide-up" style={{ animationDelay: '0.45s' }}>
            {[
              { icon: Github, href: profile.github, label: 'GitHub' },
              { icon: Linkedin, href: profile.linkedin, label: 'LinkedIn' },
              { icon: Mail, href: `mailto:${profile.email}`, label: 'Email' },
            ].map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="p-2.5 rounded-lg bg-white/5 border border-white/10 text-ink-300 hover:text-white hover:bg-white/10 transition-all duration-200 hover:-translate-y-0.5"
              >
                <Icon size={20} />
              </a>
            ))}
            <span className="inline-flex items-center gap-1.5 text-sm text-ink-400 ml-2">
              <MapPin size={16} /> {profile.location}
            </span>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 lg:mt-20 grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 animate-slide-up" style={{ animationDelay: '0.6s' }}>
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="text-center lg:text-left p-4 lg:p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors duration-200"
            >
              <p className="font-display font-extrabold text-3xl lg:text-4xl text-white">{stat.value}</p>
              <p className="mt-1 text-sm text-ink-400 font-medium">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#about"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 text-ink-500 hover:text-brand-400 transition-colors animate-bounce-slow"
        aria-label="Scroll down"
      >
        <ArrowDown size={24} />
      </a>
    </section>
  );
}
