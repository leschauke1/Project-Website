import { useState } from 'react';
import { Mail, Github, Linkedin, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { profile } from '@/data/portfolio';

export function Contact() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Please enter your name';
    if (!form.email.trim()) e.email = 'Please enter your email';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Please enter a valid email';
    if (!form.message.trim()) e.message = 'Please enter a message';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    const subject = encodeURIComponent(`Portfolio contact from ${form.name}`);
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name}\n${form.email}`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setForm({ name: '', email: '', message: '' });
    }, 4000);
  };

  const contactCards = [
    { icon: Mail, label: 'Email', value: profile.email, href: `mailto:${profile.email}` },
    { icon: Github, label: 'GitHub', value: 'github.com/lesleychauke', href: profile.github },
    { icon: Linkedin, label: 'LinkedIn', value: 'linkedin.com/in/lesleychauke', href: profile.linkedin },
  ];

  return (
    <section id="contact" className="py-20 lg:py-28 bg-ink-950 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-20" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-brand-500/10 rounded-full blur-[150px]" />

      <div
        ref={ref}
        className={`relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <div className="text-center mb-14">
          <p className="text-brand-400 font-semibold text-sm tracking-widest uppercase">Contact</p>
          <h2 className="mt-2 font-display font-bold text-3xl lg:text-4xl text-white">
            Let's build something together
          </h2>
          <div className="mt-4 w-16 h-1 bg-brand-500 rounded-full mx-auto" />
          <p className="mt-6 text-ink-400 max-w-xl mx-auto">
            I'm currently open to new opportunities and interesting collaborations.
            Whether you have a project in mind or just want to say hi, my inbox is always open.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-4">
            {contactCards.map(({ icon: Icon, label, value, href }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-4 p-5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-brand-400/30 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-brand-500/20 flex items-center justify-center group-hover:bg-brand-500 transition-colors">
                  <Icon className="text-brand-400 group-hover:text-white transition-colors" size={22} />
                </div>
                <div>
                  <p className="text-sm text-ink-400">{label}</p>
                  <p className="text-white font-medium group-hover:text-brand-300 transition-colors">{value}</p>
                </div>
              </a>
            ))}
            <div className="flex items-center gap-4 p-5 rounded-2xl bg-white/5 border border-white/10">
              <div className="w-12 h-12 rounded-xl bg-brand-500/20 flex items-center justify-center">
                <MapPin className="text-brand-400" size={22} />
              </div>
              <div>
                <p className="text-sm text-ink-400">Location</p>
                <p className="text-white font-medium">{profile.location}</p>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <form
              onSubmit={handleSubmit}
              className="p-6 lg:p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm space-y-5"
            >
              {sent && (
                <div className="flex items-center gap-3 p-4 rounded-xl bg-brand-500/20 border border-brand-400/30 text-brand-200 animate-fade-in">
                  <CheckCircle2 size={20} />
                  <p className="text-sm font-medium">Your email client is opening. Thank you for reaching out!</p>
                </div>
              )}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-ink-300 mb-1.5">
                  Name
                </label>
                <input
                  id="name"
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-ink-500 focus:outline-none focus:border-brand-400 focus:ring-1 focus:ring-brand-400 transition-colors"
                  placeholder="Jane Doe"
                />
                {errors.name && <p className="mt-1 text-sm text-red-400">{errors.name}</p>}
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-ink-300 mb-1.5">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-ink-500 focus:outline-none focus:border-brand-400 focus:ring-1 focus:ring-brand-400 transition-colors"
                  placeholder="jane@example.com"
                />
                {errors.email && <p className="mt-1 text-sm text-red-400">{errors.email}</p>}
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-ink-300 mb-1.5">
                  Message
                </label>
                <textarea
                  id="message"
                  rows={5}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-ink-500 focus:outline-none focus:border-brand-400 focus:ring-1 focus:ring-brand-400 transition-colors resize-none"
                  placeholder="Tell me about your project or just say hi..."
                />
                {errors.message && <p className="mt-1 text-sm text-red-400">{errors.message}</p>}
              </div>
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-brand-500 text-white font-semibold hover:bg-brand-600 transition-all duration-200 shadow-lg shadow-brand-500/30 hover:shadow-brand-500/50 hover:-translate-y-0.5"
              >
                <Send size={18} /> Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
