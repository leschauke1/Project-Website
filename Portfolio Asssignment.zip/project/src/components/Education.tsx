import { GraduationCap, Award, BadgeCheck, ExternalLink } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { education, certifications } from '@/data/portfolio';

export function Education() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="education" className="py-20 lg:py-28 bg-white">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <div className="text-center mb-14">
          <p className="text-brand-600 font-semibold text-sm tracking-widest uppercase">Education & Certifications</p>
          <h2 className="mt-2 font-display font-bold text-3xl lg:text-4xl text-ink-900">
            Qualifications
          </h2>
          <div className="mt-4 w-16 h-1 bg-brand-500 rounded-full mx-auto" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Education */}
          <div>
            <h3 className="flex items-center gap-2 font-display font-bold text-xl text-ink-900 mb-6">
              <GraduationCap className="text-brand-600" size={24} /> Education
            </h3>
            <div className="space-y-6">
              {education.map((edu) => (
                <div
                  key={edu.degree}
                  className="relative p-6 rounded-2xl border border-ink-100 bg-ink-50/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="absolute top-6 right-6 text-xs font-semibold text-ink-400 bg-white px-3 py-1 rounded-full border border-ink-200">
                    {edu.period}
                  </div>
                  <h4 className="font-display font-semibold text-lg text-ink-900 pr-20">{edu.degree}</h4>
                  <p className="text-brand-600 font-medium mt-1">{edu.institution}</p>
                  <p className="mt-3 text-sm text-ink-600 leading-relaxed">{edu.description}</p>
                  <p className="mt-3 inline-block text-xs font-semibold text-ink-500 bg-brand-50 px-3 py-1 rounded-md">
                    {edu.gpa}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <div>
            <h3 className="flex items-center gap-2 font-display font-bold text-xl text-ink-900 mb-6">
              <Award className="text-brand-600" size={24} /> Certifications
            </h3>
            <div className="space-y-4">
              {certifications.map((cert) => (
                <div
                  key={cert.credentialId}
                  className="group flex items-start gap-4 p-5 rounded-2xl border border-ink-100 hover:border-brand-200 hover:shadow-md transition-all duration-300"
                >
                  <div className="w-11 h-11 rounded-xl bg-brand-100 flex items-center justify-center shrink-0 group-hover:bg-brand-500 transition-colors">
                    <BadgeCheck className="text-brand-600 group-hover:text-white transition-colors" size={22} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-ink-900 text-sm leading-snug">{cert.title}</h4>
                    <p className="text-sm text-ink-500 mt-0.5">{cert.issuer} · {cert.date}</p>
                    <p className="text-xs text-ink-400 mt-1 font-mono">ID: {cert.credentialId}</p>
                  </div>
                  <ExternalLink size={16} className="text-ink-300 group-hover:text-brand-500 transition-colors mt-1 shrink-0" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
